package com.vanced.manager.model

import android.graphics.drawable.Drawable

data class LinkModel(
    val linkIcon: Drawable?,
    val linkUrl: String
)