package com.vanced.manager.model

data class VancedPrefModel(
    val name: String,
    val value: String
)