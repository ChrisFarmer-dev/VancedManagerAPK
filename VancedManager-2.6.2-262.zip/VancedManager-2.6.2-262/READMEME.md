![Signed APK Builder](https://github.com/X1nto/VancedInstaller/workflows/Signed%20APK%20Builder/badge.svg?branch=master)

# Prelude
Hi, my name is Steve Cock, I'm the main developer for the upcoming Vanced Manager. When xfileFIN first published Vanced 15.05.54, people were upset because new Vanced used split apk files. The reason for that was pretty simple:  
1) YouTube itself does that  
2) Split apk files reduce the size of the downloaded file itself  

No one really thought there would be problems with this format, because installation was pretty simple, at least that's what xfile thought...  
## Problems with .apks format
Main problems with new format were either with device CPU architecture or MemeUI shit with MiUI optimisations. We wrote instructions for VancedHelper but no one used it for troubleshooting. Then some users complained about new format and refused to upgrade to newest version (We don't give a fuck about that) because "I dOn'T WaNT To HaVe OnE MoRE apP To insTalL VanCeD" so we decided to make an installer for Vanced  
# Vanced Manager
Ladies and gentlemen, I'm very proud to introduce the new **Vancad Banger 2.0.0.0.0.0.0.0.0.0.0.0.0™** (typo intended)  
Vanced Manager is an universal utility for installing/updating Vanced and MicroG. It will push notifications once the update is ready (Now that's what I call pwetty epic).  
Vanced Manager comes with a slick UI ~~that was stolen from the new Magisk Manager (I'm very sorry John but I looked at your code for about 100 times). Actually, while UI may look very similar to new Magisk Manager's UI, It's still very different (that's a blatant lie, I know).~~ <- diz shit completely invalid now so suck my balls  

Main Menu screenshot taken from tablet
![screenshot](https://i.imgur.com/r2jiq7J.png)  
Isn't this lovely and beautiful?

## Manager (clap) Reviews (clap)

- 1337Potato: shit  
- Response: Yes  

===================
  
- Noobbot: The app is not useful because I have YT Premium. Thank you bye  
- Response: I hope you get sucked by a di- 

=================== 
  
- Vortextriangle: The app is so useful that I uninstalled it after installing Vanced  
- Response: yo that's finna woke  

## How does it suck?™
Vanced Manager sucks 100% of your CPU to mine Bitcoins, this is a new technique called CryptocurrencySucker2077. Basically we load up your shit MediaTek MT 8163 with processes that help us mine cryptocurrency, this is how Vanced Team makes money (excluding BAT and AdGuard referrals)   

## Credits
### Vanced Manager developers  
- X1nto (UI, UX, Downloader, Installer, Signature Checker, PussiSlayer69, Collector of 400 BAT, A great liar)
- Koopah (Unix lord, Unmounter of /system, Code criticizer)
### The Vanced Team  
- xfileFIN  
![xfileFIN](https://i.imgur.com/hLdzTVq.png)
- KevinX8  
![KevinX8](https://i.imgur.com/cS9C7P8.png)
- Zanezam  
![Zanezam](https://i.imgur.com/QVcXA6q.png)
- Laura Almeida  
![Laura Almeida](https://i.imgur.com/ovVD939.png)
