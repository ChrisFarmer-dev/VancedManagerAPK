package com.vanced.manager.core.presentation

import androidx.lifecycle.ViewModel

class BaseViewModel : ViewModel() {
    //TODO
}