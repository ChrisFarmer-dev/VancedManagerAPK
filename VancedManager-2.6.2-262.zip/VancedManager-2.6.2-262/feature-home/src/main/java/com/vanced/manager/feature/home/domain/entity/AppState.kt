package com.vanced.manager.feature.home.domain.entity

enum class AppState {
    INSTALL,
    UPDATE,
    REINSTALL
}