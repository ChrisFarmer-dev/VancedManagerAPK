package com.vanced.manager.model

data class AppVersionsModel(
    val version: String,
    val value: String
)