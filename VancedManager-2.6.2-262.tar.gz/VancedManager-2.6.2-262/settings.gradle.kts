rootProject.name = "Vanced Manager"

include(":app")

include(":core-presentation", ":core-ui" , ":core-mvi")

include(":feature-home")

include(":library-network")
